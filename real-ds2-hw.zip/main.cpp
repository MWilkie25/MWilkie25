#include <iostream>
#include<fstream>
using namespace std;

struct node{
    int coe,exp;
    node * next;

};
class equation{
    node * begin, * last;
    
public:
    equation();
   
    void  insert (int , int );
    int set_coe(int a);
  int set_exp(int b);
  void reader(int a,int b);
  void printout(equation);
  void print_value(ofstream &ln);
  void sort(node *);
  void sum(equation,equation);
  void read(ifstream &fl);
  void print(ofstream &);
  int sum();
};
equation::equation()//default constructor
{
    begin=NULL;
    last=NULL;
}

void equation :: read(ifstream &fl)
{
  node *temp; 
temp = new node();
begin= temp;
fl>>temp->coe;
fl>>temp->exp;
while((temp->coe!=0)&&(temp->exp!=0)){
temp->next=new node();
temp=temp->next;
fl>>temp->coe;
fl>>temp->exp;
}

}

void equation:: insert(int x, int y){
    node*temp;
    temp= new node ();
    temp-> coe=x;
    temp-> exp=y;
    temp-> next=NULL;
    
    if(begin==NULL)
    {
        begin=temp;
        last=temp;
    }
 else{
    if (temp->exp>begin->exp)
{ temp->next=begin;
begin=temp;
}
else if (temp->exp>last->exp)
{
  last->next=temp;
  last=temp;
}
 }
 
    }



void equation:: print(ofstream &fout){
    node*temp;
    temp = begin;
    while(temp != NULL){
   
    if(temp->coe == 1)
        cout<<temp->coe;
        
    else
        cout<< temp->coe<<"X^"<<temp->exp;
        temp = temp->next;
   if(temp!=NULL)
        cout<<" + ";
    }
   
}
int equation::sum(){
node *temp;
int sum=0;
temp=begin;
while(temp!=NULL)
{
if(temp->exp==temp->next->exp){
  sum+=temp->coe;
  temp=temp->next;
}

}
return (sum);
cout<<"the sum is:"<<sum;
}
//void equation::sum()

int main() {
int x,y;
  ifstream infile;
  ofstream outfile;
  infile.open("in.txt");
  outfile.open("out.txt");
equation m;
m.insert(x,y);
m.read(infile);
m.print(outfile);


infile.close();
}