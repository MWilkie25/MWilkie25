a=1
def fun():
  a=2
 

  def test():
    global a
    a=3
    print(a)
  print(a)
fun()
test()
print(a)