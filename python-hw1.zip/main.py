class MyMath:
    # first static method
    @staticmethod
    def compute_lcm(self,a,b):
        # find greater element
        if a > b:
            greater = a
        else:
            greater = b

        while(True):
            if((greater % a == 0) and (greater % b == 0)):
                compute_lcm = greater
                break
            greater += 1

        return compute_lcm

    # second function to validate power of 2
    def validate_2(self,integer):
        try:
            integer=int(integer)
            temp=2
            while temp<integer:
                if integer==temp:
                    return True
            return False
        except Exception as e:
            print(e)
    
    # function to sort dictionary
    def sort_dict(self,a):
        print("Sorted by name: ", dict(sorted(a.items(), key=lambda item: item[0])))
        print("Sorted by values: ",dict(sorted(a.items(), key=lambda item: item[1])))

a={'apple':10,'pear':5,'banana':1}
temp=MyMath()
temp.sort_dict(a)


import math
n = [1, 2, 5, 8, 7, 6, 10]

def myfunc(n):
#we use math.log2() to calculate the lagarithm value
  return math.log2(n)

#applying the above function to map the values of n
result_1 = map(myfunc, n)
#applying a lambda function to process each o n's elements
result_2 = map(lambda x: math.log2(x), n)
#printing both the results by converting them to lists
print(list(result_1))
print(list(result_2))