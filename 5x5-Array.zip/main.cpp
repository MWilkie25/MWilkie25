//Chancei White 

#include<iostream>
#include<fstream>
using namespace std;

 // I - Declaring a five by five array 
int main() 

{ 
ifstream infile;
infile.open("data.txt"); 
int arr[5][5], trans[5][5], i, j; 
int sum=0;
int count=0; 
int sum20=0; 
// II - Read data from data.txt and use them to create the matrix in the previous step*/  
for(int i=0; i<5; i++) //row
  {
  for(int j=0; j<5; j++) //col
    {
      infile>>arr[i][j];
      cout<<arr[i][j]<<"  ";

      //count evens 
      if(arr[i][j] % 2 == 0)
      count++;
    
      //count even indices
      if(j % 2 == 0)
      sum += arr[i][j];

      //int<20
      if(arr[i][j]<20)
      sum20 += arr[i][j]; 
    //trans 
      trans[j][i]=arr[i][j];
    }

    cout<<endl; 

  }

// III - Count and print the number of even integers in the matrix. 

cout<<"The count of even integers is: "<< count << endl;

cout<<"The sum of all integers in the colums with an even idex is:  "<< sum << endl;
/* IV - Calculate and print the sum of all integers in the columns with an even index value. Please note the column index begins with zero.*/
cout<<"The sum of all integers in the colums with an even idex is:  "<< sum << endl;
       /* V - Calculate the number of integers which are smaller than 20.*/
cout<<"The sum of all integers less than 20 is:"<<  sum20 << endl;
       // Display of the matrix in a table format before transposing 

        // VI -  Transpose the matrix
cout<<"The transposed array is:"<<endl;
for(i = 0; i < 5; ++i)
        for(j = 0; j < 5; ++j)
        {
            cout << " " << trans[i][j];
            if(j == 5 - 1)
                cout << endl << endl;
        }
       // Display of the matrix in a table format after transposing 
 infile.close();
 return 0;
}