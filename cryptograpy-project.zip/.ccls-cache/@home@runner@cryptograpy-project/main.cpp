#include <iostream>
#include <fstream>
using namespace std;



char ROT13(char c){

  return char
}




int main(){

  ifstream infile;
  string n;
  cout<< "what is the file name"<<endl;
  cin>>n;
  infile.open(n);
  char c;

for(int i=0;i<7;i++){
  infile>>c;
ROT13(c);

}

infile.close();

}