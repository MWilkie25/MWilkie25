//james wilkie


#include <iostream>
#include <fstream>

using namespace std;


class dancer {
int id, hrs;
float rate;
public:
dancer();
void print_value(ofstream &fl);
void read_val(ifstream &fl);
void sort_by_rate(dancer a[], float);
void sort_by_id(dancer a[], int);
int couple_counter(dancer a[], int);
void u_id(dancer a[], ofstream&);
float get_earnings(dancer a[], int);
int get_id();
int get_hrs();
float get_rate();
float total_raised(dancer a[]);
void swap(int*, int*, dancer a[]);
void best_couple(dancer a[], ofstream&);
};

dancer::dancer() //basic constructor
{
  id=0;
  rate=0;
hrs=0;
}

void dancer :: print_value(ofstream &ln) //outputting the 3 numbers from a file and printing it to a file
{
ln<<id<<"  ";
ln<<hrs<<" \t";
ln<<rate<<"\n";
}

void dancer::read_val(ifstream &fl) //reading number from a file 
{
fl>>id;
fl>>hrs;
fl>>rate;
}

void dancer::sort_by_rate(dancer a[],float b)// sorting the same id's by rates
{ 
    dancer temp; 
  for(int x =0;x<12;x++ )
  {
    if(a[x].id==a[x+1].id)
    {
      if(a[x].rate > a[x+1].rate)
      {
         temp = a[x+1];
         a[x+1] = a[x];
         a[x] = temp;
      }
    }
  }
}

void dancer ::u_id(dancer a[], ofstream &yn)//reading all the sponsors with the same id and groups them then adds there total
{
float spons;

dancer m;
yn<<a[0].id<<": "<<m.couple_counter(a,a[0].id)<<" SPONSORS, $"<<m.get_earnings(a,a[0].id)<<"\n";
for(int x = 1; x<12;x++)
{
  if(a[x].id!=a[x-1].id)
  {
    yn<<a[x].id<<": "<<m.couple_counter(a,a[x].id)<<" SPONSORS, $"<<m.get_earnings(a,a[x].id)<<"\n";
  }
}
}

void dancer::sort_by_id(dancer a[],int n)//sorting the array by id and printing each line
{  
dancer temp;
   for(int i = 0; i<n; i++) 
   {
    for(int j = i+1; j<n; j++)
    {
      if(a[j].id < a[i].id)
      {
         temp = a[i];
         a[i] = a[j];
         a[j] = temp;
      }
    }
  }
}

int dancer::couple_counter(dancer a[], int )//counting the couple 
{
int counter=1;
for(int x = 1; x<12;x++)
{
  if(a[x].id!=a[x-1].id)
  {
    counter++;
  }
}
return counter;
}

float dancer::get_earnings(dancer a[], int iD)// getting the amount earned
{
float total=0;
  for(int i=0;i<12;i++)
  {
    if(a[i].id==iD){
        total = total + (a[i].hrs*a[i].rate);
    }
  }
return total;
}

int dancer::get_id() //get id
{
return (id);
}

int dancer::get_hrs()//get hrs
{
  return (hrs);
}

float dancer:: get_rate()//get rate
{
  return (rate);
}

float dancer::total_raised(dancer a[])//adds the total raised from the array 
{
  float total;
  for(int i=0;i<12;i++)
  {
  total = total + (a[i].hrs*a[i].rate);
  }
return(total);
}


void dancer ::best_couple(dancer a[], ofstream &fl)//getting the couples that spent the most
{
  int spons,ts;
float earning,temp;
dancer m[1];
m[0].id=a[0].id;
earning=get_earnings(m, m[0].id);
for(int x = 1; x<12;x++)
{
  if(a[x].id!=a[x-1].id)
  { 
  
  temp =get_earnings(a, a[x].id);
    if(temp>earning)
    {
      earning=temp;
      m[0].id = a[x].id;
    }
  }
}
for(int x = 0; x<12;x++)
{

    spons++;
  
}
fl<<"Couple With the most money is : "<< m[0].id<<" with "<<spons<<"\t sponsers, earning $"<<temp<<endl;
}
 
int main()
{
dancer n;
dancer obj1[12];
int i;
ifstream infile;
ofstream outfile;

infile.open("in.txt");
outfile.open("outfile.txt");
for( i=0;i<12;i++)
  {
    obj1[i].read_val(infile);
  }
outfile<<"Orginal List: \n";
for( i=0;i<12;i++)
{
  obj1[i].print_value(outfile);
}
outfile<<"===============================\nSorted List: \n";
n.sort_by_id(obj1,12);
for( i=0;i<12;i++)
{
  obj1[i].print_value(outfile);
}
outfile<<"==================================\n";
outfile<<"12 Sponsors "<<n.couple_counter(obj1,i)<<" couples $ "<<n.total_raised(obj1)<<" total earnined"<<"\n========================\n";

n.u_id(obj1,outfile);


outfile<<"==============================\n";
n.best_couple(obj1, outfile);
return 0;
}








